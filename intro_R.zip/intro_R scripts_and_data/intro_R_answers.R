# Intro to R workshop
# Spring 2021
# Jennifer Huck
# UVA Library

# answers

# Your turn #1------------------------------------------------------------------

# 1. A cottage costs $100.  Create an object labeled cottage_cost 
# (You do not need to include the dollar sign.)
cottage_cost <- 100

# 2. How much does the cottage cost in Euros?  Use cottage_cost, 
# multiply by 0.82, and save as cottage_euros.
cottage_euros <- cottage_cost * 0.82


# Your turn #2------------------------------------------------------------------
# 1. When might you want numeric digits to be a string? 
#### numeric identifiers, like zip codes or social security numbers

# 4. Create a string vector consisting of 3 components. Remember the keyboard
# shortcut for the assignment <-  operator: ALT+-
names <- c("Jenn","Clay", "Ricky")


# Your Turn #3------------------------------------------------------------------

# 1. Print the last 8 lines of 'homes'
tail(homes, 8)

# 2. Take advantage of Rstudio autocomplete by typing in summary(homes$) below 
# and pick a variable that you think looks interesting.
summary(homes$totalvalue)

# 3. Save the median total value as an object.  
(total_value_median <- median(homes$totalvalue))

# 4. Fix these commands so they run correctly:
median(homes$Bedrooms, na.rm = TRUE)
mean(homes$landvalue)

# 5. What is the range of years represented by Year Built? 
# Hint 1: `range()`. Hint 2: na.rm
range(homes$yearbuilt, na.rm = TRUE)

# Your Turn #4------------------------------------------------------------------

# 1A. View the help file for filter:
?filter
# Make sure to choose the right filter command. Recall the package our filter() 
# is from.  (Hint: masking message from Tidyverse.)  How are the arguments 
# combined, and what is kept?
# 1B. Would you expect to get the same results for these two commands?
large_homes_small_plot <- filter (homes, finsqft > 3500, lotsize < 1.0)
large_homes_small_plot_alt <- filter (homes, finsqft > 3500 & lotsize < 1.0)
# Yes, you get the same results.

# 2. Fix these commands so they run correctly:
henley <- filter(homes, msdistrict == "Henley")
jouett <- filter(homes, msdistrict == "Jouett")

# 3A. Find all homes built before 1900.  Save the results as a new object.
old_homes <- filter(homes, yearbuilt < 1900)

# 3B. Using the object you made in 3A, what is the mean Finished Square Feet 
# of those homes? 
mean(old_homes$finsqft)

# Your Turn #5------------------------------------------------------------------
# 1. Create a scatterplot where x is FinSqFt and Y is LotSize
ggplot(data = homes, mapping = aes(x = finsqft, y = lotsize)) +
  geom_point()