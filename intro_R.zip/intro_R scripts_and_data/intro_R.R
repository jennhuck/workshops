# Intro to R workshop
# Spring 2021
# Jennifer Huck
# UVA Library

# This R Script will introduce you to scripts, installing and loading pacakages, 
# using tidyverse, keeping R up to date, viewing and changing your working 
# directory, importing data, evaulating data, and graphing Albemarle County real
# estate data. 

# Orientation to Scripts and Basic R operations---------------------------------

# Arithmetic
# Here, the plus sign is the 'operator'.  Operators are symbols that represent some sort of action.

# Run the code 1: Put the cursor anywhere in the line below, then Select the 'Run' # button near the top of the Script Editor
2+8/2
# Notice the console prints the code and the results. 

# Run the code 2: Put the cursor anywhere in the line below, then press 
# CTRL+Enter (Windows) or CMD+Enter (Mac)
(2+8)/2 
# You can also highlight some code to only run certain sections of the command 
# or script, then press CTRL+Enter/CMD+Enter to run.
# Highlight the part within the parentheses in the line above, then press 
# CTRL+Enter or CMD+Enter.

# Notice these comments.  You should use lots of comments when you write your 
# own scripts!  Do yourself a favor, and leave comments for the future version of # yourself. Preface comments with a hashtag: `#`.  You can also use hashtags to 
# "comment out" parts of your script when you are testing your code. 

# Let's make an object
# R statements where you create an object take this form:
# object <- value 
# Say in your head "object gets value"
# We are using the assignment operator: <- 
# Use <- instead of =

# Let's make some objects for housing square feet 
cottage <- 1000   # See how it gets saved in your Environment
mansion <- 10000  # aka "mansion gets ten thousand"

# Object names cannot start with a number, and they may not have spaces.
# Try your best to make object names explicit and short.
# Include spaces around your operators.  Spaces make your script easier to read.

# Tip: Keyboard shortcut: For assignment operator '<-' use ALT+-
# Mini-Your Turn: Below, type 'house', then press ALT+-, then type 6000, then run:


# Take advantage of RStudio autocomplete facilty: 
# Mini-Your Turn: type the first 3 letters of cottage, press Tab or Enter, then 
# run:


Cottage <- 4000   # R is cAse sEnsiTive

cottage / 2       # We can do arithmetic with R objects
cottage + mansion # Prints to console, we aren't saving this as an object in the
                  # Environment

cottage <- 2000   # We can reassign objects
cottage           # Verify by looking in the Environment or printing to console

two_homes <- cottage + mansion  # Save our arithmetic as a new object
# Tip: use snake_case by separating lowercase words with _.  
# it_is_easy_to_read

rm(Cottage)       # Remove an object
Cottage           # Now we get an error, because the object no longer exists

# Your turn #1------------------------------------------------------------------

# 1. A cottage costs $100.  Create an object labeled cottage_cost 
# (You do not need to include the dollar sign.)


# 2. How much does the cottage cost in Euros?  Use cottage_cost, 
# multiply by 0.82, and save as cottage_euros.


# Data Types--------------------------------------------------------------------

# scalar: holds one value at a time
# numeric
x <- 1
y <- 2.5
class(x)

# logical
m <- x > y  # Is x larger than y?
n <- x < y  # Is x smaller than y?
m
n
class(m)

# character (string)
d <- "cottage"
a <- "1"; b <- "2.5" # Are they different from x and y we used earlier?
x + y
a + b

# Vector - a sequence of data elements of the same basic type
# Numeric vector:
o <- c(1,2,5.3,6,-2,4)           

# Character vector:
p <- c("bedroom","bathroom","kitchen","living room","basement")

# Logical vector
q <- c(TRUE,TRUE,FALSE,TRUE,FALSE,TRUE)            

# indexing vectors - use brackets to reference elements in a vector
o[3]                       # pulls 3rd element
p[3:5]                     # pulls 3th-5th elements
q[c(1,3)]                  # pulls non-sequential elements

# matrix - a two-dimensional rectangular layout consisting of the same basic type
t <- matrix(
     1:12,                 # the data components
     nrow=4,               # number of rows
     ncol=3,               # number of columns
     byrow = FALSE)        # fill matrix by columns
t                          # print the matrix

# list - an ordered collection of objects 
w <- list(name="Jenn", mynumbers=o, mymatrix=t, age=5.3)

# data frame - similar to a matrix, except columns can be different data types 
# (i.e., can be numeric, string, logical, factor, etc.).  This is the data
# structure you are likely to use the most. 

# We will revisit data frames after we open up our Albemarle homes data. 

# Functions---------------------------------------------------------------------
# We have already used a few functions:
# c() function (combine or concatenate) to make a vector
# rm() to remove objects
# class() to determine what class an object is

# Functions are like verbs.  Objects are like nouns.  Functions allow you to do 
# things with your objects.

# Note that you usually put something inside the parethesis next to the function 
# name.  But not always.
Sys.Date()

# Have questions about a function? Put a ? in front to get the R documentation:
?matrix
# Note the Usage section which shows you the "Arguments" the function takes, e.g.,
# matrix(data = NA, nrow = 1, ncol = 1, byrow = FALSE, dimnames = NULL)
# Compare that to how we ran the matrix function several lines up (~line 120)
# Note the labels that makes it easy for humans to understand

# You can run functions without argument labels, all in one row: 
u <- matrix(1:16, 4, 4, FALSE)        
u 
# But it's harder for humans to read, so you might as well use those labels! 

# Your turn #2------------------------------------------------------------------
# 1. When might you want numeric digits to be a string? 


# 2. Create a string vector consisting of 3 components. Remember the keyboard
# shortcut for the assignment <-  operator: ALT+-


#### Jump back to Intro to R website: "Using packages".

# Clear our workspace-----------------------------------------------------------

# Let's clear the objects we just made from our workspace since we don't need 
# them anymore.  Try the remove function (below), or click the Broom icon in the
# Environment console.
rm(list = ls())

# Loading tidyverse, reading conflicts------------------------------------------

# Let's load the tidyverse package now 
library(tidyverse) 
# Remember, you only install a package once, but you must load it every new R session. 

# Note the message that we see in the Console.  You should see what packages
# were loaded (readr, dplyr, ggplot2, etc.) and conflicts.  You should see 2 conflicts:
# x dplyr::filter() masks stats::filter()
# x dplyr::lag()    masks stats::lag()
# Those are okay! 

# If you see a Warning Message in red text below the conflicts, that is error
# you need to fix.

# Note the message we got about masking.  You can read that as:
# The filter command in the dplyr package masks the filter command in the stats
# package.  

# View and Change Your Working Directory----------------------------------------

# get your working directory
getwd()

# Set working the working directory to wherever you saved this script and
# albemarle_homes_2020.csv.  

# You can do this via point-and-click:
# Session...Set Working Directory...Choose Directory

# You can also set the working directory in the console.  Copy the file path
# that leads to where you saved the workshop files.

# Windows example: Here is an example of a setting a Windows working directory:
# setwd("C:/Users/jah2ax/Box Sync/_R/workshops/intro_to_R_Spring_2020") 
# Windows users: note the FORWARD slashes.  Windows default is a backslash.
# You have to change the backslashes to forward slashes for this to work in the 
# console. Also note the beginning drive letter, .e.g, "C:"

# Mac example: Here is an example of setting a Mac working directory:
# setwd("/users/jah2ax/Box Sync/_R/workshops/intro_to_R_Spring_2020")
# Mac users: your default is a backslash, which R likes, so that's good!
# There is no drive letter as with Windows.   

# Paste YOUR working directory file path here, between the quotes:
setwd("") 

# Verify the directory is correct
# Note that you can see the working directory listed at the top of the Console
getwd() 


# Import homes data-------------------------------------------------------------

# You have several options for importing data.  let's try a few!

# 1. Save the file to your working directory, and simply pull the file from 
# there. Since you already saved the file, and you just set your working 
# directory, just put the file name in quotes. 
homes <- read.csv("albemarle_homes_2020.csv")

# homes is now saved into memory as a data object.  Look for it in the 
# Environment pane. 

# 2. We have been relying on read.csv from the utils package. There are 
# other options.  Let's try the read_csv function from the readr package that
# comes with tidyverse.
homes_readr <- read_csv("albemarle_homes_2020.csv")

# 3. Point and click: Look in the Environment window for the "Import Dataset: 
# From Text (base)" button.  
# This method loses points because it is not very reproducible. 

# These are examples of data frames - tabular data made up of heterogenous data.
# Tabular in that you have a table of rows and columns.  Rows are generally 
# observations. Columns are generally variables.  Heterogenous in that the data 
# type of each column can vary: numeric, string, factor, etc.

# With our Homes data, we can see we have numeric data like Square Feet, and 
# strings like Condition. 


# Evaluate Data-----------------------------------------------------------------

# Get an overall view
homes        # print to console
View(homes)  # view spreadsheet-style data viewer
             # You can also click on "homes" in your Environment pane
class(homes) # what class of object this is

# Print out a few rows
head(homes)  # prints first 6 rows
tail(homes)  # prints last 6 rows 
# We got 6 rows back, but we only want 3.  What to do?
?head               # read Arguments section
head(homes, n = 3)  # Add an argument to change your results
head(homes, 3)      # note that you get the same results as the above line since 
                    # arguments are in the right order

# Brief snippets
dim(homes)   # dimensions
nrow(homes)  # number of rows
ncol(homes)  # number of columns
names(homes) # column headings (variable names)

# Descriptive details
summary(homes) # Get a quick statistical summary of the dataset
               # Notice that some variables get a frequency count
               # while others get a six number summary (e.g., mean, median)
str(homes)     # View structure of the homes data
               # You can also view the structure by clicking on the little blue 
               # arrow next to the object in your Environment. 

# Notice the non-numeric/integer data is "Factor." Factor basically means a 
# categorical variable. "Factor w/ 6 levels" for City means there are 6 
# unique functional areas in this data. But notice the numbers. Factors are 
# actually stored as integers, and the integers have associated "labels". 

#investigate factors
levels(homes$esdistrict)

# You have the option to import or store the data as character data, if you 
# want. Pointing-and-clicking in the Environment window will do this, as will 
# using readr::read_csv
str(homes_readr) # View structure of the homes_readr data
summary(homes_readr) # Get a quick statistical summary of the dataset

# indexing dataframes - use $ to reference elements in a data frame
summary(homes$lotsize)  # Get a quick statistical summary of a single variable

# Save values by assigning objects
lot_size_mean <- mean(homes$lotsize)

# beware of missings!
summary(homes$bedroom)
mean(homes$bedroom)
mean(homes$bedroom, na.rm = TRUE)


# Your Turn #3------------------------------------------------------------------

# 1. Print the last 8 lines of 'homes'


# 2. Take advantage of Rstudio autocomplete by typing in summary(homes$) below 
# and pick a variable that you think looks interesting.


# 3. Save the median total value as an object.  


# 4. Fix these commands so they run correctly:
median(homes$Bedrooms, na.rm = TRUE)
Mean(homes$landvalue)

# 5. What is the range of years represented by Year Built? 
# Hint 1: `range()`. Hint 2: na.rm


# Filter data: A Taste of dplyr-------------------------------------------------

# It can be helpful to filter data based on values that you are interested in.
# Let's use the dplyr package (part of Tidyverse, which we already installed).

# We can subset observations based on their values
filter(homes, yearbuilt > 2000)       # returns only those observations where
                                      # YearBuilt is greater (more recent) than 2000
filter(homes, esdistrict == "Crozet") # returns only those observations where
                                      # esdistrict is Crozet
                                      # Note == for "equal to"
                                      # Note string in quotes, no quotes for numeric


crozet <- filter(homes, esdistrict == "Crozet") # save Crozet subset
View(crozet)                                    # view Crozet subset in
                                                # spreadsheet viewer

# Wrap in () to print to console
# Save results as an object
# Layer arguments
(large_homes_small_plot <- filter (homes, finsqft > 3500, lotsize < 1.0))

# Homes where sq ft is greater than 3500 OR lot size is greater than 1 acre
large_homes_or_plot <- filter (homes, finsqft > 3500 | lotsize > 1.0)
View(large_homes_or_plot)

# Combine filtered data with summary stats -
# Filter Charlottesville homes built in 2016, save as new object
# Median Total Value of 2016 Cville homes
new_crozet <- filter(homes, esdistrict == "Crozet" & yearbuilt == 2019)
median(new_crozet$totalvalue)

# RStudio Cheat sheets: dplyr
# e.g., ggplot: https://www.rstudio.com/resources/cheatsheets/#dplyr 

# Your Turn #4------------------------------------------------------------------

# 1A. View the help file for filter:

# Make sure to choose the right filter command. Recall the package our filter() 
# is from.  (Hint: masking message from Tidyverse.)  How are the arguments 
# combined, and what is kept?
# 1B. Would you expect to get the same results for these two commands?
large_homes_small_plot <- filter (homes, finsqft > 3500, lotsize < 1.0)
large_homes_small_plot_alt <- filter (homes, finsqft > 3500 & lotsize < 1.0)

# 2. Fix these commands so they run correctly:
henley <- filter(homes, msdistrict == "HENLEY")
jouett <- filter(homes, msdistrict == Jouett)

# 3A. Find all homes built before 1900.  Save the results as a new object.


# 3B. Using the object you made in 3A, what is the mean Finished Square Feet 
# of those homes? 


# Visualize data: A Taste of ggplot2--------------------------------------------

# It can be helpful to visualize data.  Let's use the ggplot2 package (part of 
# Tidyverse, which we already installed).

# histogram
ggplot(data = homes, mapping = aes(x = totalvalue)) +
  geom_histogram()
# Note data, mapping, and geom_function -- the grammar of graphics (the gg in ggplot2)

# bar chart
ggplot(homes, aes(msdistrict)) +  # note that you can drop "data", "mapping", "x", "y"
  geom_bar()                # as long as they are in the right order 
                            
# save parts of a plot, and re-use later
d <- ggplot(homes, aes(msdistrict))

d + geom_bar()  # note that we get the same bar chart as above

d + geom_bar(aes(fill = condition))  # layer more arguments to make a more 
                                     # complex graph

ggsave("homes.png") # save figure


# RStudio Cheat sheets: ggplot2
# e.g., ggplot: https://www.rstudio.com/resources/cheatsheets/#ggplot2 

#### Jump back to Intro to R website: "Organizing your project with R" 

# Projects----------------------------------------------------------------------

# Save this R script.  It should already be in a folder with 
# albemarle_real_estate.csv.  Create a project by selecting the R Project icon 
# or File...New Project...Existing Directory...select the directory (folder) 
# where this R script is saved.

# Once you start working with a project, you will notice that opening a project
# will provide you with the same working directory, the command history, and 
# easy access to your files. 

# You also get a fresh environment, so you should reload libraries and data. 

# Re-load your libraries (~line 181, loads tidyverse)
# Re-load you data (~line 237, calls data from within your working directory)

# Use projects to keep input data, R scripts, history, analytical results, and
# figures together in the same directory!

#### Jump back to Intro to R website: "A basic R project file structure" 