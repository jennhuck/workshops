# Intro to R workshop
# Spring 2021
# Jennifer Huck
# UVA Library

# This R Script will introduce you to scripts, installing and loading packages, 
# using tidyverse, keeping R up to date, viewing and changing your working 
# directory, importing data and evaluating data, using Albemarle County real
# estate data. 

# Scripts and Comments----------------------------------------------------------

# This file is an R script.  Use scripts to save your commands.  

# Notice these comments.  You should use lots of comments when you write your 
# own scripts!  Do yourself a favor, and leave comments for the future version 
# of yourself. 

# Preface comments with a hashtag: #  

# You can also use hashtags to "comment out" parts of your script when you are 
# testing your code. 

# View Your Working Directory---------------------------------------------------

# R always has a working directory set. Get your working directory:
getwd()

# Note that you can also see the working directory listed at the top of the 
# Console

# Create a RStudio Project------------------------------------------------------

# Create a project by selecting the R Project icon (upper right corner) or  
# File...New Project...Existing Directory...select the directory (folder) 
# where this R script is saved.

# Basic R operations------------------------------------------------------------

# Let's get some output from R starting with some simple math.

# Here, the plus sign is the 'operator'.  Operators are symbols that represent 
# some sort of action.

# Run the code 1: Put the cursor anywhere in the line below, then Select the 'Run' 
# button near the top of the Script Editor
2+8/2
# Notice the console prints the code and the results. 

# Run the code 2: Put the cursor anywhere in the line below, then press 
# CTRL+Enter (Windows) or CMD+Enter (Mac)
(2+8)/2 

# You can also highlight some code to only run certain sections of the command 
# or script, then press CTRL+Enter/CMD+Enter to run.
# Highlight the part within the parentheses in the line above, then press 
# CTRL+Enter or CMD+Enter.

# Notice that the Console shows a > (right-pointing carrot) when it is ready to 
# accept commands.  This time, try highlighting and running only
# (2+8 
# above, intentionally leaving out )/2.  You will see a + (plus sign) in 
# the console.  You can click into the console and press ESC, or you can 
# highlight and run the rest of the line. 

# Creating objects--------------------------------------------------------------

# It is more useful and interesting to assign values to objects.
# We create an object by using this form:
# object <- value 
# Say in your head "object gets value"
# We are using the assignment operator: <- 
# Use <- instead of =

# Let's make some objects for housing square feet 
cottage <- 1000   # Say "cottage gets one thousand"
mansion <- 10000  # See how it gets saved in your Environment

# Tip: Keyboard shortcut: For assignment operator '<-' 
# use ALT+- (for PC) or OPTION+- (for Mac)
# That is, hold the ALT/OPTION key, then press the - key (minus sign key)

# Mini-Your Turn: Below, type 'house', then press ALT+- (or OPTION+-), then type 
# 6000, then run:


# Object name tips: 
# - Object names cannot start with a number, and they may not have spaces.
# - Try your best to make object names explicit and short.
# - R is case sensitive, so house is different from House.
# - Avoid using dots in object names, for example, avoid: my.dataset

# Take advantage of RStudio autocomplete facility: 
# Mini-Your Turn: type the first 3 letters of cottage, press Tab or Enter, then 
# run:


Cottage <- 4000 # R is case sensitive, so be careful with your upper/lowercase

(condo <- 3000) # Put parenthesis around the call to print to the console

condo <- 2000   # We can re-assign objects
condo           # Verify by looking in the Environment or printing to console by
                # typing the name of the object

cottage / 2       # We can do arithmetic with R objects
cottage + mansion # Simply prints to console, we aren't saving this as an object 
                  # in the Environment

two_homes <- cottage + mansion  # Save our arithmetic as a new object
# Tidyverse style tip: use snake_case by separating lowercase words with _.  
# it_is_easy_to_read

rm(Cottage)       # Remove an object
Cottage           # Now we get an error, because the object no longer exists

# Your turn #1------------------------------------------------------------------

# Do these exercises in order!

# 1. A cottage costs $100.  Create an object labeled cottage_cost that gets the 
# value 100.  (Do not include the dollar sign.)


# 2. How much does the cottage cost in Euros?  Use cottage_cost, 
# multiply by 0.8, and save the object as cottage_euros.


# 3. Whoops - the cottage is actually $200 - twice what we thought.  
# Update cottage_cost to 200.


# 4. What do you think the current content of the object cottage_euros is? 
# Is it 80 or 160?


# Functions---------------------------------------------------------------------

# Functions are like verbs.  Objects are like nouns.  Functions allow you to do 
# things with your objects.

# Functions get one or more inputs called arguments. Functions often return a 
# value.

# Let's try a very simple function: sqrt()
sqrt(100)
# The value 100 is given to the sqrt() function, the sqrt() function calculates 
# the square root, and returns the value.

# The sqrt() function is very simple because it takes only one argument. 

# Let's try a function that can take multiple arguments: round()
round(3.14159)

# The default is to round to the nearest whole number.  If we want to round to 
# more digits, we can get more info on the round() function, by going to 
args(round)
# or looking at the help page
?round
# Let's take a quick look at the Examples section for the round() help page, and open those examples in a new script

# We see that if we want a different number of digits, we can type digits=2,
# or however many we want.
# Below, type ... round(3.14159, dig ... then press TAB ... then 2) ... then 
# ENTER


# If you provide the arguments in the exact same order as they are defined you 
# do not have to name them:
round(3.14159, 2)

# And if you do name the arguments, you can switch their order:
round(digits = 2, x = 3.14159)

# But it is good practice to put the non-optional arguments (like the number 
# you are rounding) first in your function call, and to specify the names of all
# optional arguments. If you don't, someone reading your code might have to look
# up the definition of a function with unfamiliar arguments to understand what 
# you are doing.

# Data Types--------------------------------------------------------------------

## scalar: holds one value at a time

# numeric
x <- 1
y <- 2.5

# logical
(m <- x > y)  # Is x larger than y?
(n <- x < y)  # Is x smaller than y?

# character (string)
d <- "cottage"
a <- "1" 
b <- "2.5" # Are a and b different from x and y?
x + y
a + b

## Vector - a sequence of data elements of the same basic type, most often 
# numbers and characters

# To create a vector, use the c() function...c for concatenate or combine

# Numeric vector:
cost <- c(125, 534, 98)           

# Character vector:
rooms <- c("bedroom", "bathroom", "kitchen")
# The quotes are essential for creating character vectors.  Otherwise R thinks 
# you are trying to call objects.

# Character vector missing the quotes:
rooms <- c(bedroom, bathroom, kitchen) # These objects do not exist, so you get an error

# indexing vectors - use brackets to reference elements in a vector
# R starts counting from 1.
cost[3]      # pulls 3rd element
rooms[2:3]   # pulls 2nd-3rd elements
rooms[c(1,3)]    # pulls non-sequential elements

# Your turn #2------------------------------------------------------------------
# 1. Pull the second element from the numeric vector cost (above).


# 2. Create a character vector consisting of 4 components. Remember the keyboard
# shortcut for the assignment <-  operator: ALT+- or OPTION+-


# 3. Pull the 2nd and 4th elements of the vector you created in step 2.


#### Jump back to Intro to R website: "Using packages, Using Tidyverse"

# Clear our workspace-----------------------------------------------------------

# Let's clear the objects we just made from our workspace since we don't need 
# them anymore.  Try the remove function (below), or click the Broom icon in the
# Environment console.
rm(list = ls())

# Loading packages, reading conflicts------------------------------------------

# We need more verbs! R comes pre-loaded with several packages, but one of the
# cool things about R is that people develop new functions all the time.  Those 
# functions are packaged up in...packages!  Let's load a package.  

# Recall that you installed the tidyverse package before the workshop.  
# Remember, you only *install* a package once, but you must *load* it for every # new R session.

# Let's load our first package: tidyverse 
library(tidyverse) 

# Note the message that we see in the Console.  You should see what packages
# were loaded (ggplot2, tibble, etc.) and conflicts.  You should see 2 
# conflicts:
#
# x dplyr::filter() masks stats::filter()
# x dplyr::lag()    masks stats::lag()
#
# Those are okay! You can read that as:
# The filter command in the dplyr package masks the filter command in the stats
# package. 

# If you see a Warning Message in red text below the conflicts, that is an error
# you need to fix.

# Import homes data - Our First Data Frame_-------------------------------------

# You have several options for importing data.  let's try a few!

# 1.
# Make sure your file is saved to your working directory, and simply pull the 
# file from there. Let's use base R's read.csv() function: 
homes_base <- read.csv("data-raw/albemarle_homes_2020.csv")

# 2. 
# Now that we have installed tidyverse, let's try using the read_csv() function 
# from the readr sub-package.
homes <- read_csv("data-raw/albemarle_homes_2020.csv")

# Let's compare homes and homes_readr
homes_base
homes
# One of the biggest differences is the way that the objects print to the 
# console. homes is technically a tibble, and a tibble is simply the tidyverse's # version of a data frame.  Tibbles print nicely!

# 3. 
# Point and click: Look in the Environment window for the "Import Dataset: 
# From Text (base) or Text (readr)" button.  
# This method loses points because it is not very reproducible, because you are 
# not saving how you imported your data within your script.

# These are examples of data frames - a data structure that is a table made up 
# of heterogenous data.  A table has rows and columns.  Rows are generally
# observations and columns are generally variables.  Heterogenous means that the # data type of each column can vary: numeric, string, factor, etc.

# With our homes data, we can see we have numeric data like Square Feet, and 
# strings like Condition. 

# Evaluate Data, Part 1---------------------------------------------------------

# Get an overall view
homes        # print to console
View(homes)  # view spreadsheet-style data viewer
             # You can also click on "homes" in your Environment pane

# Size
nrow(homes)  # number of rows
ncol(homes)  # number of columns
dim(homes)   # number of rows and number of columns (the DIMensions of the object)

# Content (print out a few rows)
head(homes)  # prints first 6 rows
tail(homes)  # prints last 6 rows 

# Names
names(homes) # column names (variable names)

# Summaries
summary(homes) # Get a quick statistical summary of the dataset
               # Notice that some variables get a frequency count
               # while others get a six number summary (e.g., mean, median)
str(homes)     # View structure of the homes data
               # You can also view the structure by clicking on the little blue 
               # arrow next to the object in your Environment. 
glimpse(homes) # returns the number of columns and rows of the tibble, the names 
               # and class of each column, and previews as many values will fit 
               # on the screen.  glimpse() is from the dplyr or tibble package,
               # while everything else in this section is from base R.

# Factors: categorical data-----------------------------------------------------

# Notice in our summary() and str() print outs, we see a lot of character data. 
# Let's focus on `hsdistrict`.  There are only 3 high schools in Albemarle 
# county (plus a category for "Unassigned" in our dataset).  The high schools 
# are fixed and known - making it a categorical variable. In R, categorical data # are called factors.  Factors are a class of data, just like numeric or 
# character data.  

# Here is a quick (lazy) way of importing all character (string) data as factors:
homes_factors <- read.csv("data-raw/albemarle_homes_2020.csv", stringsAsFactors = TRUE)
str(homes_factors)

# Compare str(homes) and str(homes_factor).  The character data in 'homes' are 
# now Factors with Levels. Looking at 'hsdistrict' again, it shows "Factor w/ 4 
# levels". Also notice the numbers that follow. Factors are stored in memory as 
# integers, and the integers have associated "labels". 

# investigate factors for high school district
levels(homes_factors$hsdistrict)

# Check out tidyverse's forcats package for more details on how to manage factors.

# Evaluate Data, Part 2---------------------------------------------------------

#### Indexing dataframes 

# Use $ to reference elements in a data frame
summary(homes$lotsize)  # Summary of lotsize variable
mean(homes$lotsize)     # Mean of lotsize variable.

#### Use logical vectors to query data

# Note:
# TRUE is stored as 1
# FALSE is stored as 0

# number of homes over $1,000,000
sum(homes$totalvalue > 1e6) # 1e6 is fast way of writing 1,000,000
                            # (i.e., 1 followed by 6 zeros) in R
# For each observation, if the total value is over $1,000,000, R considers that 
# TRUE, which is stored as a 1.  Then R sums up all those 1's with the sum() 
# function.

# proportion of homes over $1,000,000 (mean of 0s and 1s as a proportion of 1s)
mean(homes$totalvalue > 1e6)

#### Use tables() to create tables

# count of homes by hs district
table(homes$hsdistrict)

# count of homes by cooling (central air) status
table(homes$cooling)

# table of homes in hsdistrict by cooling status
# the first argument fills in the rows, the second fills in the columns
table(homes$hsdistrict, homes$cooling)

# Beware of missing data--------------------------------------------------------

# Missing data is represented by NA.
sum(is.na(homes$bedroom)) # there is 1 observation with missing bedroom data.

# Most functions will return NA if the data include missing values.
mean(homes$bedroom)

# You can add the argument na.rm = TRUE to ignore missing values.
mean(homes$bedroom, na.rm = TRUE)

# Your Turn #3------------------------------------------------------------------

# 1. Print the last 8 lines of 'homes'


# 2. Use the function median() to calculate the median of the number of full 
# baths (fullbath) in 'homes'


# 3. Create a table that includes middle school district (msdistrict) as rows, 
# and condition as columns.


# 4. Fix these commands so they run correctly:
median(homes$Bedrooms, na.rm = TRUE)
Mean(homes$landvalue)

# Filling out our Project Directory--------------------------------------------- 

# This part is not specific to R or RStudio.

# Using a consistent folder structure across your projects will help keep things 
# organized and make it easy to find your files in the future.

#### Create a chart ####

# Let's create a quick chart.

# bar chart of homes total value 
ggplot(homes, aes(x = totalvalue)) +  # don't worry about this code!
  geom_histogram()                     # save your questions for the data viz
                                       # workshop!

# In the Files pane (lower right), verify that the folder displays your working 
# directory...click on "New Folder"...create a new folder called...output.  
# (The new folder might not be visible in the Files pane right away.)

# save figure
ggsave("output/total_value.png")

#### Save our data ####

# Let's save our data now. 

# (I admit, this isn't a perfect example, since we didn't really make any changes
# to the raw dataset.  We might as well use our homes_factors since we took the 
# time to convert the strings to factors.)

# In the Files pane (lower right), verify that the folder displays your working 
# directory...click on "New Folder"...create a new folder called...data-processed.  
# (The new folder might not be visible in the Files pane right away.)

# Save your homes_factors object as an Rds file.
saveRDS(homes_factors, file = "data-processed/homes_factors.Rds")

#### Bonus: a folder for your report ####

# In the Files pane (lower right), verify that the folder displays your working 
# directory...click on "New Folder"...create a new folder called...documents.  
# (The new folder might not be visible in the Files pane right away.)

#### Jump back to Intro to R website: "Keeping R up to date" 